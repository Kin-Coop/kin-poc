(function(angular, $, _) {
  // Declare a list of dependencies.
  angular.module('crmMosaico', CRM.angRequires('crmMosaico'));
})(angular, CRM.$, CRM._);
