<?php

class CRM_Mosaico_Graphics_Exception extends \CRM_Core_Exception {

}
