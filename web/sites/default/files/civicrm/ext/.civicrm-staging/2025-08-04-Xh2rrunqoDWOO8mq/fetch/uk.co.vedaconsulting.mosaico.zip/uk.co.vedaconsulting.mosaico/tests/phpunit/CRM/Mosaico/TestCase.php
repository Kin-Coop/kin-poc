<?php

class CRM_Mosaico_TestCase extends PHPUnit\Framework\TestCase {

  use \Civi\Test\Api3TestTrait;

}
