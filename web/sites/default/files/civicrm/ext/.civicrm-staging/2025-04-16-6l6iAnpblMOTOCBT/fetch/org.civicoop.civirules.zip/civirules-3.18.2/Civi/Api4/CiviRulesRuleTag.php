<?php

namespace Civi\Api4;

/**
 * CiviRulesRuleTag entity.
 *
 * Provided by the civirules extension.
 *
 * @searchable secondary
 * @package Civi\Api4
 */
class CiviRulesRuleTag extends Generic\DAOEntity {

}
