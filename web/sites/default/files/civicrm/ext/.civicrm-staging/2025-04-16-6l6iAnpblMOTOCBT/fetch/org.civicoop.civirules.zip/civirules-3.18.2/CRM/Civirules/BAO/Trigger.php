<?php

/**
 * DAO class was renamed for API4/searchkit compatibility
 */
class_alias('CRM_Civirules_BAO_CiviRulesTrigger', 'CRM_Civirules_BAO_Trigger');
