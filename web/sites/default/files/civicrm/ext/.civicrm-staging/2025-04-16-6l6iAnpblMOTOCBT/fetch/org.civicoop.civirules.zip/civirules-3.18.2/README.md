# org.civicoop.civirules
Rule based engine to automate administrative processes (native extension).

Latest documentation: https://docs.civicrm.org/civirules/en/latest/

Repository can be found at: https://lab.civicrm.org/extensions/civirules
 
PLEASE NOTE: IF YOU ARE UPGRADING TO VERSION 2.x MAKE SURE YOU SAVE YOUR EXISTING RULES FIRST AS UPDATE WILL REMOVE THE EXISTING ACTIONS AND CONDITIONS!!! This will be fixed asap.

PLEASE NOTE: BEFORE YOU ARE UPGRADING TO VERSION 2.10 PLEASE NOTE YOUR RULES WITH THE TRIGGER CASE IS ADDED!

They will be deleted! (see below and need to be changed)
In release 2.10 the Case Added trigger is removed (see https://lab.civicrm.org/extensions/civirules/issues/45). Please use the Case Activity trigger with activity type Ope Case instead!
