<?php

return [
  0 => 
  [
    'name' => 'Cron:Civirules.Cron',
    'entity' => 'Job',
    'params' => 
    [
      'version' => 3,
      'name' => 'Civirules cron',
      'description' => 'Trigger civirules cron triggers',
      'run_frequency' => 'Always',
      'api_entity' => 'Civirules',
      'api_action' => 'Cron',
      'parameters' => '',
    ],
  ],
];