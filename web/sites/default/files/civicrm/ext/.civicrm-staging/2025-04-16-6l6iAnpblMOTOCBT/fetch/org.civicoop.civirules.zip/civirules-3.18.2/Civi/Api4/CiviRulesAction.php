<?php

namespace Civi\Api4;

/**
 * CiviRulesAction entity.
 *
 * Provided by the civirules extension.
 *
 * @searchable secondary
 * @package Civi\Api4
 */
class CiviRulesAction extends Generic\DAOEntity {

}
